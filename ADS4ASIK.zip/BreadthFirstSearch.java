import java.util.*;

public class BreadthFirstSearch extends Search {
    public BreadthFirstSearch(WeightedGraph graph, Vertex source) {
        super(graph, source);
    }

    @Override
    public List<Vertex> getPath(Vertex destination) {
        Map<Vertex, Vertex> parentMap = new HashMap<>();
        Queue<Vertex> queue = new LinkedList<>();
        Set<Vertex> visited = new HashSet<>();

        queue.add(source);
        visited.add(source);
        parentMap.put(source, null);

        while (!queue.isEmpty()) {
            Vertex current = queue.poll();
            if (current.equals(destination)) {
                break;
            }

            for (Edge edge : graph.getEdges(current)) {
                Vertex neighbor = edge.getDestination();
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    parentMap.put(neighbor, current);
                    queue.add(neighbor);
                }
            }
        }

        // Если путь до destination не найден
        if (!parentMap.containsKey(destination)) {
            return new ArrayList<>();
        }

        // Восстанавливаем путь
        List<Vertex> path = new ArrayList<>();
        Vertex current = destination;
        while (current != null) {
            path.add(current);
            current = parentMap.get(current);
        }
        Collections.reverse(path);
        return path;
    }
}