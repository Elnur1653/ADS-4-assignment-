import java.util.*;

public class WeightedGraph {
    private Map<Vertex, List<Edge>> adjacencyList;

    public WeightedGraph() {
        this.adjacencyList = new HashMap<>();
    }

    // Добавить вершину
    public void addVertex(Vertex vertex) {
        adjacencyList.putIfAbsent(vertex, new ArrayList<>());
    }

    // Добавить ребро (ориентированное)
    public void addEdge(Vertex source, Vertex destination, double weight) {
        addVertex(source);
        addVertex(destination);
        adjacencyList.get(source).add(new Edge(source, destination, weight));
    }

    // Получить соседей вершины
    public List<Edge> getEdges(Vertex vertex) {
        return adjacencyList.getOrDefault(vertex, new ArrayList<>());
    }

    // Получить все вершины
    public Set<Vertex> getVertices() {
        return adjacencyList.keySet();
    }
}