import java.util.List;

public abstract class Search {
    protected WeightedGraph graph;
    protected Vertex source;

    public Search(WeightedGraph graph, Vertex source) {
        this.graph = graph;
        this.source = source;
    }

    // Абстрактный метод для поиска пути
    public abstract List<Vertex> getPath(Vertex destination);
}