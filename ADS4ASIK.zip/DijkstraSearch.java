import java.util.*;

public class DijkstraSearch extends Search {
    public DijkstraSearch(WeightedGraph graph, Vertex source) {
        super(graph, source);
    }

    @Override
    public List<Vertex> getPath(Vertex destination) {
        Map<Vertex, Double> distances = new HashMap<>();
        Map<Vertex, Vertex> parentMap = new HashMap<>();
        PriorityQueue<Vertex> pq = new PriorityQueue<>(Comparator.comparing(distances::get));
        Set<Vertex> visited = new HashSet<>();

        // Инициализация расстояний
        for (Vertex vertex : graph.getVertices()) {
            distances.put(vertex, Double.POSITIVE_INFINITY);
        }
        distances.put(source, 0.0);
        pq.add(source);
        parentMap.put(source, null);

        while (!pq.isEmpty()) {
            Vertex current = pq.poll();
            if (visited.contains(current)) continue;
            visited.add(current);

            if (current.equals(destination)) {
                break;
            }

            for (Edge edge : graph.getEdges(current)) {
                Vertex neighbor = edge.getDestination();
                if (visited.contains(neighbor)) continue;

                double newDist = distances.get(current) + edge.getWeight();
                if (newDist < distances.get(neighbor)) {
                    distances.put(neighbor, newDist);
                    parentMap.put(neighbor, current);
                    pq.add(neighbor);
                }
            }
        }

        // Если путь до destination не найден
        if (!parentMap.containsKey(destination) || distances.get(destination) == Double.POSITIVE_INFINITY) {
            return new ArrayList<>();
        }

        // Восстанавливаем путь
        List<Vertex> path = new ArrayList<>();
        Vertex current = destination;
        while (current != null) {
            path.add(current);
            current = parentMap.get(current);
        }
        Collections.reverse(path);
        return path;
    }
}