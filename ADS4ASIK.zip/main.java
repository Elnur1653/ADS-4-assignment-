public class main {
    public static void main(String[] args) {
        WeightedGraph graph = new WeightedGraph();

        Vertex v0 = new Vertex("A");
        Vertex v1 = new Vertex("B");
        Vertex v2 = new Vertex("C");
        Vertex v3 = new Vertex("D");

        graph.addEdge(v0, v1, 1);
        graph.addEdge(v1, v2, 2);
        graph.addEdge(v0, v3, 4);
        graph.addEdge(v3, v2, 1);

        Search bfs = new BreadthFirstSearch(graph, v0);
        System.out.println("BFS path: " + bfs.getPath(v2));

        Search dijkstra = new DijkstraSearch(graph, v0);
        System.out.println("Dijkstra path: " + dijkstra.getPath(v2));
    }
}